# VeriFyz Protocol — Agent 3 Build Package

This package contains a complete front-end scaffold and inputs for Replit Agent 3 to produce the finished app.

## Project Structure
- `src/components/Nav.jsx` — sticky top nav (Home, Verify, Token Presale, API, About)
- `src/components/Hero.jsx` — HERO section (title + tagline + CTA) at the very top
- `src/components/Features.jsx` — four-card row ("Anonymous Verification", "True Proof of Presence", "Trust on Chain", "Unlimited Tokens")
- `src/components/Timeline.jsx` — five-step process diagram (Event Creation → User Check-In → Proof Generation → Proof Submission → Reward Settlement)
- `src/components/WinnersCTA.jsx` — glowing banner "Lifetime Reward Winners Selected" + "Get Notified" button
- `src/components/Presale.jsx` — presale block: Countdown + (left) WalletConnect card + (right) Calculator card + status note
- `src/components/ProofSubmit.jsx` — Proof submission placeholder card
- `src/components/Footer.jsx` — footer with links and copyright
- `src/components/Countdown.jsx` — reads timestamps from `.env`
- `src/components/Calculator.jsx` — USD → VFYZ + MATIC calculator
- `src/components/WalletConnect.jsx` — connection placeholder (Agent 3 wires provider)
- `src/lib/eth.js` — provider/signer helper
- `contracts/VerifyzVerifierV2.sol` — minimal contract header with timeline constants
- `docs/` — any whitepaper/contract PDFs found
- `src/assets/` — copied user images: long_app_image.png

## Exact Section Order (Top → Bottom)
1. **Nav** (sticky)  
2. **Hero** (centered title, tagline, glow CTA → anchors to Presale)  
3. **Features** (row of 4 neon cards)  
4. **Timeline** (5-step grid; last step spans full width)  
5. **WinnersCTA** (full-width glowing banner)  
6. **Presale**  
   - Countdown  
   - 2-column grid: **Left = WalletConnect**, **Right = Calculator**  
   - Status bar note "Presale runs Sept 15–29 • Launches Oct 6"  
7. **ProofSubmit** (card)  
8. **Footer** (border-top, links on right)

## Styling
- Global gradient background + subtle fingerprint glow
- Neon cyan edges (`shadow-glow`, `card-neon`, `button-neon` classes)
- Mobile-first grid; 4-up features row collapses to 1–2 columns on small screens

## ENV
Copy `.env.example` → `.env` and set:
```
VITE_RPC_URL=... (Polygon)
VITE_VERIFIER_ADDRESS=0x...
```
MATIC/USD and token price are overridable via `.env`.

## Agent 3 — Tasks
1. Replace placeholder wallet connect with Wagmi/EIP-1193 provider.
2. Wire calculator CTA to `contributeToPresale()` in the deployed contract.
3. Implement `submitProof()` call from ProofSubmit card.
4. Apply final typography and import any additional assets in `src/assets/`.
