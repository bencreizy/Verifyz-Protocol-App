import { useMemo, useState } from 'react'

export default function Calculator(){
  const [usd, setUsd] = useState('100')
  const maticUsd = Number(import.meta.env.VITE_MATIC_USD || 0.27)
  const tokenPrice = Number(import.meta.env.VITE_TOKEN_PRICE || 0.05)

  const tokens = useMemo(() => {
    const val = parseFloat(usd || '0')
    if (isNaN(val)) return 0
    return Math.floor((val / tokenPrice) * 1000) / 1000
  }, [usd, tokenPrice])

  const matic = useMemo(() => {
    const val = parseFloat(usd || '0')
    if (isNaN(val) || !maticUsd) return 0
    return Math.round((val / maticUsd) * 1e6) / 1e6
  }, [usd, maticUsd])

  return (
    <div className="card-neon p-6">
      <div className="grid md:grid-cols-2 gap-5">
        <div>
          <label className="block text-sm mb-1">USD Amount</label>
          <input value={usd} onChange={e=>setUsd(e.target.value)} className="w-full bg-white/10 border border-white/20 rounded-xl px-3 py-2" placeholder="100" />
          <p className="text-xs text-white/60 mt-2">MATIC/USD: ${maticUsd} • Token Price: ${tokenPrice}</p>
        </div>
        <div className="space-y-2">
          <div className="text-sm">You’ll Receive</div>
          <div className="text-2xl">{tokens} VFYZ</div>
          <div className="text-sm text-white/70">{matic} MATIC (approx.)</div>
        </div>
      </div>
      <div className="mt-4 text-right">
        <button className="button-neon">Buy VFYZ</button>
      </div>
    </div>
  )
}
