export default function Nav(){
  return (
    <header className="sticky top-0 z-50 backdrop-blur bg-black/20 border-b border-white/10">
      <div className="section flex items-center justify-between h-16">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-cyan-400/40 border border-cyan-300/30" />
          <span className="font-bold">VeriFyz Protocol</span>
        </div>
        <nav className="hidden md:flex gap-6 text-sm">
          <a href="#home" className="opacity-90 hover:opacity-100">Home</a>
          <a href="#verify" className="opacity-90 hover:opacity-100">Verify</a>
          <a href="#presale" className="opacity-90 hover:opacity-100">Token Presale</a>
          <a href="#api" className="opacity-90 hover:opacity-100">API</a>
          <a href="#about" className="opacity-90 hover:opacity-100">About</a>
        </nav>
      </div>
    </header>
  )
}
