import Countdown from './Countdown.jsx'
import Calculator from './Calculator.jsx'
import WalletConnect from './WalletConnect.jsx'

export default function Presale(){
  return (
    <section id="presale" className="section py-14">
      <h2 className="text-3xl mb-2">VeriFyz Token Presale</h2>
      <p className="text-white/75 mb-6">Buy VeriFyz Tokens at $0.05 during our presale grand launch.</p>
      <div className="mb-6"><Countdown /></div>
      <div className="grid md:grid-cols-2 gap-6 items-start">
        <WalletConnect />
        <Calculator />
      </div>
      <div className="card-neon p-4 mt-6 text-sm text-white/80">
        Presale runs Sept 15–29 • Launches Oct 6
      </div>
    </section>
  )
}
