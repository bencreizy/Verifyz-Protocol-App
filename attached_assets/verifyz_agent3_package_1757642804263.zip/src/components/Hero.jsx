export default function Hero(){
  return (
    <section id="home" className="section pt-20 pb-14 text-center">
      <h1 className="text-4xl md:text-6xl mb-4">VeriFyz Protocol</h1>
      <p className="text-white/80 max-w-2xl mx-auto">
        Proof of Presence. Verified, Anonymous, Rewarded.
      </p>
      <div className="mt-8">
        <a href="#presale" className="button-neon inline-block">Get Started</a>
      </div>
    </section>
  )
}
