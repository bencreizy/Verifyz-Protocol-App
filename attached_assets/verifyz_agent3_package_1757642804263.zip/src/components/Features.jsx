const items = [
  { title: 'Anonymous Verification', text: 'Verify your location without exposing your identity.' },
  { title: 'True Proof of Presence', text: 'GPS, device signals, and QR/NFC challenges prevent spoofing.' },
  { title: 'Trust on Chain', text: 'Every verified presence is immutably recorded.' },
  { title: 'Unlimited Tokens', text: 'Scalable rewards and growth across events and partners.' },
]

export default function Features(){
  return (
    <section className="section py-10">
      <div className="grid md:grid-cols-4 gap-5">
        {items.map((it, i) => (
          <div key={i} className="card-neon p-5">
            <h3 className="text-lg mb-2">{it.title}</h3>
            <p className="text-white/75 text-sm">{it.text}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
