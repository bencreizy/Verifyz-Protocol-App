const steps = [
  { n: 1, title: 'Event Creation', text: 'Organizer posts eventId, geofence & time window on-chain.' },
  { n: 2, title: 'User Check-In', text: 'Scan QR / tap NFC at venue. Challenge includes nonce & expiry.' },
  { n: 3, title: 'Proof Generation', text: 'Device collects geohash + attestation & creates ZK proof.' },
  { n: 4, title: 'Proof Submission', text: 'Submit proof & nullifier to Verifier contract.' },
  { n: 5, title: 'Reward Settlement', text: 'Rewards escrow pays tokens and logs presence receipt.' },
]

export default function Timeline(){
  return (
    <section className="section py-12">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card-neon p-6">{steps[0].n}. {steps[0].title}<p className="text-white/75 mt-2 text-sm">{steps[0].text}</p></div>
        <div className="card-neon p-6">{steps[1].n}. {steps[1].title}<p className="text-white/75 mt-2 text-sm">{steps[1].text}</p></div>
        <div className="card-neon p-6">{steps[2].n}. {steps[2].title}<p className="text-white/75 mt-2 text-sm">{steps[2].text}</p></div>
        <div className="card-neon p-6">{steps[3].n}. {steps[3].title}<p className="text-white/75 mt-2 text-sm">{steps[3].text}</p></div>
        <div className="card-neon p-6 md:col-span-3">{steps[4].n}. {steps[4].title}<p className="text-white/75 mt-2 text-sm">{steps[4].text}</p></div>
      </div>
    </section>
  )
}
