import Nav from './components/Nav.jsx'
import Hero from './components/Hero.jsx'
import Features from './components/Features.jsx'
import Timeline from './components/Timeline.jsx'
import WinnersCTA from './components/WinnersCTA.jsx'
import Presale from './components/Presale.jsx'
import ProofSubmit from './components/ProofSubmit.jsx'
import Footer from './components/Footer.jsx'

export default function App(){
  return (
    <div className="bg-verifyz-gradient min-h-screen bg-fingerprint">
      <Nav />
      <main>
        <Hero />
        <Features />
        <Timeline />
        <WinnersCTA />
        <Presale />
        <ProofSubmit />
      </main>
      <Footer />
    </div>
  )
}
